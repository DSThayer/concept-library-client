library(testthat);
library(ConceptLibraryClient);

test_check("ConceptLibraryClient");